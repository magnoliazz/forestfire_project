package com.example.forestfire.web;

import com.example.forestfire.entity.FireAlert;
import com.example.forestfire.repository.FireAlertRepository;
import com.example.forestfire.service.FileUploadService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.sql.Timestamp;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/fire")
public class FireAlertController {

    @Autowired
    private FireAlertRepository fireAlertRepository;

    @Autowired
    private FileUploadService fileUploadService;  // 引入 FileUploadService

    // 注入不同系统下的 Python 可执行文件和检测脚本路径
    @Value("${file.pythonExe.windows}")
    private String pythonExeWindows;

    @Value("${file.pythonExe.linux}")
    private String pythonExeLinux;

    @Value("${file.detectScript.windows}")
    private String detectScriptWindows;

    @Value("${file.detectScript.linux}")
    private String detectScriptLinux;

    /**
     * 根据操作系统选择对应的 Python 可执行文件路径
     */
    private String getPythonExe() {
        String os = System.getProperty("os.name").toLowerCase();
        if (os.contains("win")) {
            return pythonExeWindows;
        } else {
            return pythonExeLinux;
        }
    }

    /**
     * 根据操作系统选择对应的检测脚本路径
     */
    private String getDetectScript() {
        String os = System.getProperty("os.name").toLowerCase();
        if (os.contains("win")) {
            return detectScriptWindows;
        } else {
            return detectScriptLinux;
        }
    }

    /**
     * 文件上传接口，接收文件并处理
     * @param file 上传的文件
     * @return 文件上传及火灾检测结果
     */
    @PostMapping("/upload")
    public Map<String, Object> uploadFile(@RequestParam("file") MultipartFile file) {
        Map<String, Object> response = new HashMap<>();
        try {
            // 调用 FileUploadService 保存文件并获取文件路径
            String filePath = fileUploadService.uploadFile(file);

            // 执行 Python 脚本进行火灾检测
            Map<String, Object> result = executePythonScript(filePath);

            // 保存检测结果
            if ("success".equals(result.get("status"))) {
                int flameCount = (int) result.get("flameCount");
                double confidence = (Double) result.get("confidence");
                FireAlert fireAlert = new FireAlert();
                fireAlert.setTimestamp(new Timestamp(System.currentTimeMillis()));
                fireAlert.setFlameCount(flameCount);
                fireAlert.setConfidence((float) confidence);
                fireAlertRepository.save(fireAlert);

                // 更正图片路径：原始图像路径存储为 uploads 目录
                result.put("originalImagePath", "/uploads/" + new File(filePath).getName());

                // 检测结果图像路径存储为 results 目录
                String resultImagePath = "/results/" + new File(filePath).getName(); // 使用结果目录
                result.put("resultImagePath", resultImagePath);
            }

            response.putAll(result);
        } catch (Exception e) {
            e.printStackTrace();
            response.put("status", "error");
            response.put("message", "文件上传或检测时出现错误！");
        }
        return response;
    }

    /**
     * 接收 Base64 格式的图像，保存并执行火灾检测
     * @param payload 包含 Base64 图像数据的请求体
     * @return 图像检测结果
     */
    @PostMapping("/detectFrame")
    public Map<String, Object> detectFrame(@RequestBody Map<String, String> payload) {
        Map<String, Object> response = new HashMap<>();
        try {
            String imageBase64 = payload.get("image");
            if (imageBase64 == null || !imageBase64.contains(",")) {
                response.put("status", "error");
                response.put("message", "图像数据缺失或格式不正确！");
                return response;
            }

            String base64Data = imageBase64.split(",")[1];
            byte[] imageBytes = Base64.getDecoder().decode(base64Data);

            // 保存截图并获取文件路径
            String filePath = fileUploadService.saveBase64Image(imageBytes);

            // 执行检测
            Map<String, Object> result = executePythonScript(filePath);

            response.putAll(result);
        } catch (Exception e) {
            e.printStackTrace();
            response.put("status", "error");
            response.put("message", "图像处理或检测过程中出现错误！");
        }
        return response;
    }

    /**
     * 执行 Python 脚本并解析结果
     * @param filePath 上传文件的路径
     * @return Python 脚本的检测结果
     */
    private Map<String, Object> executePythonScript(String filePath) {
        Map<String, Object> result = new HashMap<>();
        try {
            // 根据不同操作系统选择对应的 python 执行文件和检测脚本
            ProcessBuilder pb = new ProcessBuilder(getPythonExe(), getDetectScript(), filePath);
            pb.redirectErrorStream(true);
            Process process = pb.start();

            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line);
            }
            process.waitFor();

            System.out.println("🐍 Python输出：" + output);

            // 提取 JSON 部分（从第一个 { 开始）
            String json = output.toString().trim();
            int idx = json.indexOf("{");
            if (idx != -1) json = json.substring(idx);

            // 解析 JSON
            ObjectMapper mapper = new ObjectMapper();
            result = mapper.readValue(json, Map.class);
        } catch (Exception e) {
            e.printStackTrace();
            result.put("status", "error");
            result.put("message", "执行 Python 脚本时出现错误！");
        }
        return result;
    }
}
