package com.example.forestfire.config;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.stereotype.Component;

@Component
public class CustomAuthenticationFailureHandler implements AuthenticationFailureHandler {

    @Override
    public void onAuthenticationFailure(HttpServletRequest request,
                                        HttpServletResponse response,
                                        AuthenticationException exception)
            throws IOException, ServletException {

        // 根据异常类型设置不同的错误提示
        String errorMessage = "登录失败：用户名或密码错误！";

        if (exception.getClass().getSimpleName().equals("UsernameNotFoundException")) {
            errorMessage = "登录失败：用户不存在！";
        } else if (exception.getClass().getSimpleName().equals("BadCredentialsException")) {
            errorMessage = "登录失败：密码不正确！";
        }

        // 为了方便调试，我们将错误提示作为 URL 参数传递（注意：正式环境不要暴露太详细的信息）
        response.sendRedirect("/login.html?errorMsg=" + java.net.URLEncoder.encode(errorMessage, "UTF-8"));
    }
}
