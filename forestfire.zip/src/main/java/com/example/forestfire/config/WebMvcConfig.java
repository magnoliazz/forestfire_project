package com.example.forestfire.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 映射上传图片路径
        registry.addResourceHandler("/uploads/**")
                .addResourceLocations("file:E:/forestfire/forestfire/uploads/");

        // 映射YOLO检测结果图片路径（根据实际路径调整）
        registry.addResourceHandler("/results/**")
                .addResourceLocations("file:E:/forestfire/forestfire_project/results/");
    }
}
