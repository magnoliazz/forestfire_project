package com.example.forestfire.service;

import com.example.forestfire.entity.User;
import com.example.forestfire.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public User registerNewUser(String username, String rawPassword) {
        // 1. 检查用户名是否已存在
        if (userRepository.findByUsername(username) != null) {
            throw new RuntimeException("用户名已存在");
        }

        // 2. 创建并保存新用户
        User user = new User();
        user.setUsername(username);
        // 加密存储密码
        user.setPassword(passwordEncoder.encode(rawPassword));

        return userRepository.save(user);
    }
}
