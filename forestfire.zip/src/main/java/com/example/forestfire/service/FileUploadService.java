package com.example.forestfire.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Service
public class FileUploadService {

    // 从配置文件中获取上传路径
    @Value("${file.upload-dir.windows}")
    private String windowsUploadDir;

    @Value("${file.upload-dir.linux}")
    private String linuxUploadDir;

    /**
     * 获取操作系统的上传路径
     * @return 当前操作系统下的上传路径
     */
    private String getUploadDir() {
        String os = System.getProperty("os.name").toLowerCase();
        if (os.contains("win")) {
            // Windows 系统
            return windowsUploadDir;
        } else {
            // Linux 或其他系统
            return linuxUploadDir;
        }
    }

    /**
     * 处理文件上传
     * @param file 上传的文件
     * @return 文件的保存路径
     * @throws IOException 如果文件保存时出现错误
     */
    public String uploadFile(MultipartFile file) throws IOException {
        // 获取操作系统相关的路径
        String uploadDir = getUploadDir();

        // 生成文件名和保存路径
        String fileName = System.currentTimeMillis() + "_" + file.getOriginalFilename();
        Path filePath = Paths.get(uploadDir, fileName);

        // 创建目录（如果目录不存在）
        Files.createDirectories(filePath.getParent());

        // 将文件保存到指定目录
        file.transferTo(filePath.toFile());

        // 返回文件的保存路径
        return filePath.toString();
    }

    /**
     * 保存Base64编码的图像
     * @param imageBytes 图像的字节数组
     * @return 保存的文件路径
     * @throws IOException 如果文件保存时出现错误
     */
    public String saveBase64Image(byte[] imageBytes) throws IOException {
        // 获取操作系统相关的路径
        String uploadDir = getUploadDir();

        // 生成文件名和保存路径
        String fileName = "frame_" + System.currentTimeMillis() + ".png";
        Path filePath = Paths.get(uploadDir, fileName);

        // 创建目录（如果目录不存在）
        Files.createDirectories(filePath.getParent());

        // 将Base64图像字节保存为文件
        Files.write(filePath, imageBytes);

        // 返回文件的保存路径
        return filePath.toString();
    }
}
