package com.example.forestfire.repository;

import com.example.forestfire.entity.FireAlert;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FireAlertRepository extends JpaRepository<FireAlert, Long> {
    // 你可以在这里添加自定义查询方法
}
