package com.example.forestfire.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import java.sql.Timestamp;

@Entity
public class FireAlert {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;           // 主键ID
    private Timestamp timestamp;  // 火灾发生的时间
    private int flameCount;       // 火焰数量
    private float confidence;     // 检测的置信度

    // 无参构造函数（JPA规范中最好保留）
    public FireAlert() {
    }

    // 有参构造函数（可选）
    public FireAlert(Timestamp timestamp, int flameCount, float confidence) {
        this.timestamp = timestamp;
        this.flameCount = flameCount;
        this.confidence = confidence;
    }

    // Getter 和 Setter
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    public int getFlameCount() {
        return flameCount;
    }

    public void setFlameCount(int flameCount) {
        this.flameCount = flameCount;
    }

    public float getConfidence() {
        return confidence;
    }

    public void setConfidence(float confidence) {
        this.confidence = confidence;
    }
}
